#include "FileController.h"

bool testConstructor();
bool testDestructor();
bool testUserExists();
bool testGetUser();
bool testSaveUser();
bool testCreateUser();
bool testDeleteUser();

class FilerController;

bool testFileController()
{
	return testConstructor() &&
		testDestructor() &&
		testUserExists() &&
		testGetUser() &&
		testSaveUser() &&
		testCreateUser() &&
		testDeleteUser();
}

bool testConstructor()
{
	FileController *f = new FileController;
	if(f) return true;
	return false;
}

bool testDestructor()
{
	FileController *f = new FileController;
	delete f;
	if(!f) return true;
	return false;
}

bool testUserExists()
{
	FileController f;

	User u = User("test@email.com", "test", "test2", "test3");
	f.createUser(u);
	return f.userExists("test@email.com") &&
		! f.userExists("not@good.com");
}

bool testGetUser()
{
	FileController f;

	User u = User("test@email.com", "test", "test2", "test3");
	f.createUser(u);
	return f.getUser(u, "test@email.com", "64a0e0a34d99dce03a8c5a4c237a4b5a") &&
		! f.getUser(u, "test@email.com", "password") &&
		! f.getUser(u, "an@email.com", "64a0e0a34d99dce03a8c5a4c237a4b5a")	;
}

bool testSaveUser()
{
	FileController f;

	User u = User("test@email.com", "test", "test2", "test3");
	User v = User("test@email.com", "test", "test2", "test3");
	f.createUser(u);
	return f.saveUser(u) && !f.saveUser(v);
	
}

bool testCreateUser()
{
	FileController f;
	User x = User("test@email.com", "test", "test2", "test3") ;
	User y = User("", "test", "test2", "test3");
	User z = User("test@email.com", "", "test2", "test3");
	User w = User("test@email.com", "test", "", "test3");
	User r = User("test@email.com", "test", "test2", "");
	return f.createUser(x) &&
		! f.createUser(y) &&
		! f.createUser(z) &&
		! f.createUser(w) &&
		! f.createUser(r);
}

bool testDeleteUser()
{
	FileController f;

	User u = User("test@email.com", "test", "test2", "test3");
	User v = User("test2@email.com", "test", "test2", "test3");
	f.createUser(u);
	f.createUser(v);

	return f.deleteUser("test2@email.com") &&
		! f.userExists("test2@email.com") &&
		f.userExists("test@email.com");
}
