#ifndef OURAPPLICATION_H
#define OURAPPLICATION_H

#include <Wt/WApplication>
#include <Wt/WEnvironment>
#include "User.h"
#include "FileController.h"
class OurApplication : public Wt::WApplication
{

public:
	OurApplication(const Wt::WEnvironment& env);
	~OurApplication(void);

private:
	enum Pages{Landing, Home, CreateUser, UserProfile};

	std::string title = "Title";

	
	Wt::WContainerWidget *wholePage;			

	Wt::WContainerWidget *header;
	Wt::WContainerWidget *content;
	Wt::WContainerWidget *footer;
		
	
	User user;				//used as session to trace current user
	bool loggedIn;
		
        void login(Wt::WLineEdit* login_email, Wt::WLineEdit* login_password, Wt::WText* msg);
	void signUp(Wt::WLineEdit* first_name,Wt::WLineEdit* last_name,Wt::WLineEdit* email, Wt::WLineEdit* password, Wt::WLineEdit* passcheck,Wt::WText* reg_msg);
	void edit(Wt::WLineEdit* first_name,Wt::WLineEdit* last_name, Wt::WText *msg);
	void logout();
	void delete_user();
	void change_password(Wt::WLineEdit *old_pass, Wt::WLineEdit *new_pass, Wt::WLineEdit *new_check, Wt::WText *msg);

	void addHeader();
	void addContent();
	void addFooter();
	
	void showLanding();
	void showHome();
	void showAbout();
	void showRegister();
	void showLogin();
	void showLogout();
	void showAccount();
};

#endif
