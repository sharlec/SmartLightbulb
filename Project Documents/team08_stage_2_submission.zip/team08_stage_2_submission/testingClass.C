#include <iostream>
#include "User.h"
#include <ctime>

using namespace std;
int main(){
    User testUser;
    string firstName;
    string lastName;
    string username;
    string password1, password2;
    string hashedpassword;
    time_t regTime;
    time_t logTime;

    cout <<"///////////////NAME, USERNAME TEST/////////////////\nPlease enter first name:" << endl;
    getline(cin, firstName);
    cout <<"Please enter Lasstname:" << endl;
    getline(cin, lastName);
    cout <<"Please enter a username/email" << endl;
    getline(cin, username);

    if(testUser.checkNameFormat(firstName)){
        if(testUser.checkNameFormat(lastName)){
            cout << "firstName and lastName format correct" << endl;
            testUser.setFirstName(firstName);
            testUser.setLastName(lastName);
            cout << "Hello, " << testUser.getFirstName() << " " << testUser.getLastName() << endl;
        }else{
            cout << "wrong format for last name" << endl;
        }
    }else{
        cout << "wrong format for first name" << endl;
    } 

    

    if(testUser.checkUsernameFormat(username)){
        testUser.setEmail(username);
        cout<< "Username good: " << testUser.getEmail() << endl;
    }else{
        cout << "Username not in proper format " << endl;
    }


    cout <<"///////////////PASSWORD TEST/////////////////\nPlease enter a password" << endl;
    getline(cin, password1);
    cout << "please re-enter password" << endl;
    getline(cin, password2);
    if(testUser.comparePassword(password1, password2)){
        if(testUser.checkPasswordFormat(password1)){   
            testUser.setHashedPassword(testUser.hashPassword(password1));
            cout << "Password set to : " << testUser.getHashedPassword() << endl;
            
            if(testUser.getHashedPassword().compare(testUser.hashPassword(password1)) ==0){
                cout << "Hashing matches, hashfunction works" << endl;
            }else {
                cout << "Hashing does not provide consistent resutls" << endl;
            }
        }else {
            cout << "passwords match but in wrong format. Must be 6-12 alpha/numeric characters long" << endl;
        }
    }else{
        cout <<"passwords do not match" << endl;
    }

    cout<<"//////////////////CREATING USER//////////////////////////////"<< endl;
    User newUser = User(username, password1, firstName, lastName);
    newUser.setRegisterTime(time(NULL));
    newUser.setLastLogin(time(NULL));
    cout<<"newUser created email: "<<newUser.getEmail() <<" name: "<<newUser.getFirstName() << " " << newUser.getLastName() << endl;
    cout << "last login: " << newUser.getLastLogin() <<" registration time: " << newUser.getRegisterTime() << endl;

    User emptyUser;
    if(emptyUser.empty()){
        cout << "empty() shows no user::passes first test" << endl;
        if(!newUser.empty()){
            cout << "newUser is not empty. Passes test" << endl;
        }else cout<<"newUser shows empty. Fails test" << endl;
    }else cout << "Failure to show emptyUser is empty" << endl;
}