/* 
 *Author: Chris Steward, Charles Chang
 *Description: Main source file and GUI controller class,
 *does the general controlling of how the program functions and
 *calls functions from other classes as it needs them
 *Date: November 5, 2017
 */

#include <Wt/WContainerWidget>
#include <Wt/WText>
#include <Wt/WWidget>
#include <Wt/WCssStyleSheet>
#include <Wt/WPushButton>
#include <Wt/WDialog>
#include <Wt/WLineEdit>
#include <Wt/WBreak>
#include <Wt/WAnchor>
#include <Wt/WLink>


#include "OurApplication.h"


using namespace Wt;

/*
 *Function Name: OurApplication
 *Description: Constructor for the application class, switches on a few basic
 * things and creates the basic look of the website
 *return: OurApplicaiton object
 */	
OurApplication::OurApplication(const WEnvironment& env)	: WApplication(env)
{
	this->loggedIn = false;
	
	//set style
	this->useStyleSheet("style.css");
		
	wholePage = new Wt::WContainerWidget(root());
	wholePage->setId("whole-page");
	

	//add 3 sections
	addHeader();
	addContent();
	addFooter();

	//set style
	showLanding();
}


/*
 *Function Name: ~OurApplication
 *Description: Destructor for OurApplication Objects, does some cleanup of pointers
 *return: N/A
 */	

OurApplication::~OurApplication()
{
        delete header;
	delete content;
	delete footer;

	delete wholePage;
}

/*
 *Function Name: signUp
 *Description: Creates a new user and gives feedback on the webpage
 *return: N/A
 */	
void OurApplication::signUp(Wt::WLineEdit* first_name, Wt::WLineEdit* last_name,Wt::WLineEdit* email, Wt::WLineEdit* password, Wt::WLineEdit* passcheck, Wt::WText* reg_msg){

	User new_user;
	
	//make sure all inputs are not empty
	if(first_name->text().empty() || last_name->text().empty() || password->text().empty() || passcheck->text().empty() || email->text().empty()){
		reg_msg->setText("Please fill all information.");
	}
	else if(!new_user.checkUsernameFormat(email->text().narrow())){
		reg_msg->setText("Email format is not valid.");	
	}
	else if(!new_user.checkPasswordFormat( password->text().narrow())){
		reg_msg->setText("Password format is not valid");		
	}
	else if(!new_user.comparePassword( password->text().narrow(), passcheck->text().narrow()) ){
		reg_msg->setText("Two password does not match.");
	}


	else{
		//create a new user and save into database	
		new_user.setEmail(email->text().narrow());
		new_user.setFirstName(first_name->text().narrow());
		new_user.setLastName(last_name->text().narrow());
		new_user.setHashedPassword(new_user.hashPassword(password->text().narrow()));	
		FileController f_control;
		
		f_control.createUser(new_user);
		reg_msg->setText("New user created.");
	}
}

/*
 *Function Name: login
 *Description: Checks the users information and credentials and allows them to login if correct
 *return: N/A
 */	
void OurApplication::login(Wt::WLineEdit* login_email, Wt::WLineEdit* login_password, Wt::WText* msg){
		
	if(login_email->text().empty() || login_password->text().empty()){
		msg->setText("Please fill all blanks.");
	}
	else{
		
		FileController f_control;
		
		User &ref = user;
		std::cout << user.hashPassword(login_password->text().narrow()) << std::endl;
		int flag = f_control.getUser(ref,login_email->text().narrow(),user.hashPassword(login_password->text().narrow()));
		
		//flag for 3 cases, 0-valid inputs, 1-account doesn't exist, 2-wrong password
		if(flag == 0){
			this->loggedIn = true;
			addHeader();
			showHome();
		}
		else if(flag == 1){
			msg->setText("Account does not exist, sign up now!");
		}
		else{
			msg->setText("Your password is wrong.");
		}
	}
}


/*
 *Function Name: edit
 *Description: Function called when user wants to edit their information
 *return: N/A
 */
void OurApplication::edit(Wt::WLineEdit* first_name,Wt::WLineEdit* last_name, Wt::WText *msg){
	
	//make sure no empty inputs
	if(first_name->text().empty() || last_name->text().empty()){
		msg->setText("Please fill all information.");
	}

	else{
		//update the information in database
		user.setFirstName(first_name->text().narrow());
		user.setLastName(last_name->text().narrow());
		FileController f_control;
		
		f_control.saveUser(user);
		
		content->clear();
		
		content->addWidget(new WText("Your information has been updated!"));
		content->addWidget(new WBreak());				
	}
}

/*
 *Function Name: logout
 *Description: Logs the user out and changes the web page back to the landing
 *return: 
 */	
void OurApplication::logout()
{
	this->loggedIn = false;
	this->user = User();
	addHeader();
	showLanding();
}

/*
 *Function Name: delete_user
 *Description: deletes the users account and puts them back to the landing page
 *return: N/A
 */	
void OurApplication::delete_user(){
	FileController f_controller;
	f_controller.deleteUser(user.getEmail());
	WApplication::instance()->redirect("http://localhost:8080");

}

/*
 *Function Name: change_password
 *Description: Changes the users password and does some input validaiton
 *return: N/A
 */	
void OurApplication::change_password(Wt::WLineEdit *old_pass,Wt::WLineEdit *new_pass,Wt::WLineEdit *new_check, Wt::WText *msg){
	if(!this->loggedIn)
	{
		return;
	}
	
	if(old_pass->text().empty() || new_pass->text().empty() || new_check->text().empty()){
		msg->setText("Please fill all information.");
	}

	else if(!user.comparePassword(new_pass->text().narrow(), new_check->text().narrow())){
		msg->setText("Your new password does not match the repeat one.");
	}

	else{
		FileController f_control;
		User temp;
		User &ref = temp;
		int flag = f_control.getUser(ref,user.getEmail(),user.hashPassword(old_pass->text().narrow()));
		
		//flag for 3 cases, 0-valid inputs, 1-account doesn't exist, 2-wrong password
		if(flag == 0){
			std::string hash_pass = user.hashPassword(new_pass->text().narrow());
			user.setHashedPassword(hash_pass);
			User &ref2 = user;
			f_control.saveUser(ref2);
			
			content->clear();
		
			content->addWidget(new WText("Your password has been changed!"));
			content->addWidget(new WBreak());			
		}
		else{
			msg->setText("Your old password is wrong.");
		}
	}	
}


/*
 *Function Name: addHeader
 *Description: Adds the header to the website including all the buttons and links to functions to change the page
 *return: N/A
 */	
void OurApplication::addHeader()
{
	if(header == NULL) {
		header = new Wt::WContainerWidget(this->wholePage);
		header->setId("header");
	}
	else {
		header->clear();
	}

	Wt::WPushButton *homeButton = new Wt::WPushButton("Home", header);
	homeButton->setStyleClass("button");
	homeButton->clicked().connect(this, &OurApplication::showHome);
	
	Wt::WPushButton *aboutButton = new Wt::WPushButton("About Us", header);
	aboutButton->setStyleClass("button");
	aboutButton->clicked().connect(this, &OurApplication::showAbout);

	if(!this->loggedIn) {
		Wt::WPushButton *loginButton = new Wt::WPushButton("Login", header);
		loginButton->setStyleClass("button");
		loginButton->clicked().connect(this, &OurApplication::showLogin);
	
		Wt::WPushButton *registerButton = new Wt::WPushButton("Register", header);
		registerButton->setStyleClass("button");
		registerButton->clicked().connect(this, &OurApplication::showRegister);
	}
	else{
		Wt::WPushButton *accountButton = new Wt::WPushButton("My Account", header);
		accountButton->setStyleClass("button");
		accountButton->clicked().connect(this, &OurApplication::showAccount);
	
		Wt::WPushButton *logoutButton = new Wt::WPushButton("Logout", header);
		logoutButton->setStyleClass("button");
		logoutButton->clicked().connect(this, &OurApplication::showLogout);

		Wt::WContainerWidget *userDiv = new Wt::WContainerWidget(header);
		userDiv->addWidget(new Wt::WText("Welcome " + user.getFirstName() + " " + user.getLastName()));
		userDiv->setId("whoami");

	}
}

/*
 *Function Name: addContent
 *Description: Adds the bare content page to the website
 *return: N/A
 */	
void OurApplication::addContent()
{
	content = new Wt::WContainerWidget(this->wholePage);
	content->setId("content");
	Wt::WText *contentText = new Wt::WText("<p> This is some sweet content</p>");
	content->addWidget(contentText);
}


/*
 *Function Name: addFooter
 *Description: Adds the footer to the website
 *return: N/A
 */	
void OurApplication::addFooter()
{
	footer = new Wt::WContainerWidget(this->wholePage);
	footer->setId("footer");
	Wt::WText *footerText = new Wt::WText("<p>CS3307 Team 8 - Hue Light Controller Project</p>");
	footer->addWidget(footerText);
}

/*
 *Function Name: showLanding
 *Description: Shows the landing page with a greeting message
 *return: N/A
 */	
void OurApplication::showLanding()
{
	this->content->clear();
	setTitle("CS3307 Team 8 Home Page");
	content->addWidget(new WText("<h2>Welcome to CS3307 team08 Phillips Hue Light Control System.</h2>"));  
}

/*
 *Function Name: showHome
 *Description: Shows the User's home Page
 *return: N/A
 */	
void OurApplication::showHome()
{
	this->content->clear();

	content->addWidget(new WText("<h2>Home Sweet Home.</h2>"));  

}

/*
 *Function Name: showLogin
 *Description: Shows the Login page with input validation 
 *return: N/A
 */	
void OurApplication::showLogin()
{
	this->content->clear();
	
	//adding input box for login
	content->addWidget(new WText("Email:"));
	Wt::WLineEdit *login_email = new WLineEdit(this->content); 		             
	login_email->setFocus(); 	

	content->addWidget(new WText("Password:"));	                
	Wt::WLineEdit *login_password = new WLineEdit(this->content);	
	login_password->setEchoMode(Wt::WLineEdit::EchoMode(1));                     

	content->addWidget(new WBreak());

	//adding buttons for login and register
	Wt::WPushButton *login_button = new WPushButton("login");   
	login_button->setMargin(5, Left);                            
	content->addWidget(login_button);		

	//adding login msg for invalid input
	Wt::WText *msg = new WText(content);

	login_button->clicked().connect(boost::bind(&OurApplication::login,this, login_email, login_password,msg));
	login_email->enterPressed().connect(boost::bind(&OurApplication::login,this, login_email, login_password,msg));
	login_password->enterPressed().connect(boost::bind(&OurApplication::login,this, login_email, login_password,msg));	
}

/*
 *Function Name: showAbout
 *Description: Shows the about page for informaition on it about our team
 *return: N/A
 */	
void OurApplication::showAbout()
{
	this->content->clear();
	
	content->addWidget(new WText("<h2>About Us</h2>"));  
	content->addWidget(new WText("<p>We are Team 8 in the CS3307 class and this is our web page for controlling Philips Hue Lights</p>"));
	content->addWidget(new WText("<h4>Who are We?</h4>"));
	content->addWidget(new WText("<p>Our team consists of Kirk, Chris, Pedro, Jacob, and Charles. We are all Computer Science Students, Chris and Pedro are in fourth year, and Kirk, Charles, and Jacob are in third year of the Computer Science program.</p>"));
}

/*
 *Function Name: showRegister
 *Description: Shows the Registration page with all the needed info to make an account
 *return: N/A
 */	
void OurApplication::showRegister()
{
	content->clear();

	setTitle("Register");
	
	//adding input boxes
	content->addWidget(new WText("First Name:"));
	Wt::WLineEdit *first_name = new WLineEdit(content);
	first_name->setFocus();
	content->addWidget(new WBreak());

	content->addWidget(new WText("Last Name:"));
	Wt::WLineEdit *last_name = new WLineEdit(content);
	content->addWidget(new WBreak());

	content->addWidget(new WText("Email Address:"));
	Wt::WLineEdit *email = new WLineEdit(content);
	content->addWidget(new WBreak());

	content->addWidget(new WText("Password:\t"));
	Wt::WLineEdit *password = new WLineEdit(content);
	password->setEchoMode(Wt::WLineEdit::EchoMode(1));                     
	content->addWidget(new WBreak());

	content->addWidget(new WText("Repeat Password :\t"));
	Wt::WLineEdit *passcheck = new WLineEdit(content);
	passcheck->setEchoMode(Wt::WLineEdit::EchoMode(1));                     
	content->addWidget(new WBreak());

	//leave a message to user if invalid input
	Wt::WText *reg_msg = new WText(content);
	content->addWidget(new WBreak());
	

	//buttons for signuo and cancel
	WPushButton *ok = new Wt::WPushButton("Submit", content);
	ok->clicked().connect(boost::bind(&OurApplication::signUp, this, first_name, last_name, email, password, passcheck,reg_msg));	
		
	first_name->enterPressed().connect(boost::bind(&OurApplication::signUp, this, first_name, last_name, email, password, passcheck, reg_msg));
	last_name->enterPressed().connect(boost::bind(&OurApplication::signUp, this, first_name, last_name, email, password, passcheck, reg_msg));
	email->enterPressed().connect(boost::bind(&OurApplication::signUp, this, first_name, last_name, email, password, passcheck, reg_msg));
	password->enterPressed().connect(boost::bind(&OurApplication::signUp, this, first_name, last_name, email, password, passcheck, reg_msg));
	passcheck->enterPressed().connect(boost::bind(&OurApplication::signUp, this, first_name, last_name, email, password, passcheck, reg_msg));
}

/*
 *Function Name: showLogout
 *Description: Shows the logout page with a single button to logout and end the session
 *return: N/A
 */	
void OurApplication::showLogout()
{
	this->content->clear();

	WPushButton *logout = new Wt::WPushButton("Logout", content);
	logout->clicked().connect(this, &OurApplication::logout);
}


/*
 *Function Name: showAccount
 *Description: Shows the account page with the users information and the buttons to change it
 *return: N/A
 */	
void OurApplication::showAccount()
{
	this->content->clear();

	setTitle("Your Information");

	//show account information
	content->addWidget(new WText("Email: "));
	content->addWidget(new WText(user.getEmail(),content));
	content->addWidget(new WBreak());

	//set input boxes
	content->addWidget(new WText("First Name:"));
	Wt::WLineEdit *first_name = new WLineEdit(user.getFirstName(),content);
	first_name->setFocus();
	content->addWidget(new WBreak());


	content->addWidget(new WText("Last Name:"));
	Wt::WLineEdit *last_name = new WLineEdit(user.getLastName(),content);
	content->addWidget(new WBreak());
	
	//set submit and cancel button
	WText *msg = new Wt::WText(content);
	WPushButton *ok = new Wt::WPushButton("Submit", content);
	ok->clicked().connect(boost::bind(&OurApplication::edit,this, first_name, last_name,msg));

	first_name->enterPressed().connect(boost::bind(&OurApplication::edit,this, first_name, last_name,msg));
	last_name->enterPressed().connect(boost::bind(&OurApplication::edit,this, first_name, last_name,msg));

	content->addWidget(new WBreak());
	
	//Change Password stuff
		
	//set input boxes
	content->addWidget(new WText("Old Password:"));
	Wt::WLineEdit *old_pass = new WLineEdit(content);
	old_pass->setEchoMode(Wt::WLineEdit::EchoMode(1));   
	old_pass->setFocus();
	content->addWidget(new WBreak());
	
	content->addWidget(new WText("New Password:"));
	Wt::WLineEdit *new_pass = new WLineEdit(content);
	new_pass->setEchoMode(Wt::WLineEdit::EchoMode(1));   
	content->addWidget(new WBreak());

	content->addWidget(new WText("Repeat Password:"));
	Wt::WLineEdit *new_check = new WLineEdit(content);
	new_check->setEchoMode(Wt::WLineEdit::EchoMode(1));   
	content->addWidget(new WBreak());


	//set submit and cancel button
	msg = new Wt::WText(content);
	WPushButton *change = new Wt::WPushButton("Submit", content);
	change->clicked().connect(boost::bind(&OurApplication::change_password, this, old_pass, new_pass, new_check,msg));

	content->addWidget(new WBreak());

	WPushButton *deleteButton = new Wt::WPushButton("Delete Acount", content);
	deleteButton->clicked().connect(this, &OurApplication::delete_user);
}
