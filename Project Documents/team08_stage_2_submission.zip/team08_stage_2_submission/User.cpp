/* 
 *Author: Kirk Vander Ploeg
 *Description: Implementation of User. Methods to get/set User information,
 *check the format of a password or username and to compare two passwords. 
 *Also includes function to hash a password
 *Date: November 5, 2017
 */

#include <regex>
#include <Wt/WApplication>
#include <Wt/WBreak>
#include <Wt/WContainerWidget>
#include <Wt/WLineEdit>
#include <Wt/WPushButton>
#include <Wt/WText>
#include <Wt/Auth/HashFunction>
#include "User.h"

using namespace Wt;

/*
 *Function Name:User
 *Description:Default Constructor
 *Parameters:N/A
 *return:N/A
 */
User::User(){}

/*
 *Function Name:User
 *Description:Constructor to create a User object with and email, password
 *First and Last name. Initializes memeber variables
 *Parameters:string inEmail, string password, string inFirstName, string inLastName
 *return:N/A
 */
User::User(std::string inEmail, std::string password, 
			std::string inFirstName, std::string inLastName){
	email = inEmail;
	hashedPassword = this->hashPassword(password);
	firstName = inFirstName;
	lastName = inLastName;
} 
	
/*
 *Function Name:~User
 *Description:Default destructor
 *Parameters:N/A
 *return:N/A
 */
User::~User(){}


/*
 *Function Name:get<variable>
 *Description:getter methods to return values of member variables
 *Parameters:N/A
 *return:a string representing the member variable requested or time_t in the
 *case of getRegisterTime and getLastLogin
 */
std::string User::getEmail(){return email;}					
std::string User::getHashedPassword(){return hashedPassword;}
std::string User::getFirstName(){return firstName;}
std::string User::getLastName(){return lastName;}
std::time_t User::getRegisterTime(){return registerTime;}
std::time_t User::getLastLogin(){return lastLogin;}


/*
 *Function Name:set<variable>
 *Description:setter methods to adjust values of member variables
 *Parameters:String of the changed value for the specified setter. time_t in 
 *case of GetResiterTime and getLastLogin
 *return: void
 */	
void User::setEmail(std::string inputEmail){email = inputEmail;}
void User::setFirstName(std::string inputFirstName){firstName = inputFirstName;}
void User::setLastName(std::string inputLastName){lastName = inputLastName;}
void User::setHashedPassword(std::string inputHashedPassword){hashedPassword = inputHashedPassword;}
void User::setRegisterTime(time_t inputRegisterTime){registerTime = inputRegisterTime;}
void User::setLastLogin(time_t inputLastLogin){lastLogin = inputLastLogin;}

/*
 *Function Name: hashPassword
 *Description:Takes a string and hashes it to an unreadable seemingly 
 *random string
 *Parameters:string password - the password to be hashed
 *return: returns the hashed version of the password
 */	
std::string User::hashPassword(std::string password){
	const std::string& ms = password;
	const std::string salt = "hello world";
	Wt::Auth::MD5HashFunction func;
  	return func.compute(ms, salt);
}


/*
 *Function Name:comparePassword
 *Description:This method will take two passwords and check that they are equal
 *Parameters:two strings to compare against eachother
 *return: true if match false otherwise
 */
bool User::comparePassword(std::string originalPassword, 
	std::string rewrittenPassword){
		if(originalPassword.compare(rewrittenPassword) == 0){
			return true;
		}else return false;
}


/*
 *Function Name:changePassword
 *Description:This function will change the value of the password variable
 *iif the function is provided with the original password and two matching new
 *passwords
 *Parameters:string enteredPassword - the original passowrd to be changed
 *string newPassword, string rewrittenPassword- the new password twice to check 
 *that they are equal. The hashed password variable is updated if okay
 *return: 0 if valid, 2 if new passwords do not match, 1 if original password
 *does not match
 */	
int User::changePassword(std::string enteredPassword,
			std::string newPassword, std::string rewrittenPassword){
	
	std::string enteredHash = hashPassword(enteredPassword);
	
	if(enteredHash.compare(hashedPassword) == 0){
		if(comparePassword(newPassword, rewrittenPassword) == true){
			hashedPassword = hashPassword(newPassword);
			return 0;
		}return 2;
	}else return 1;

}


/*
 *Function Name:checkUsernameFormat
 *Description:Checks a given string for valid username or email format. Valid
 *format is a string that is xy@xz. Where x is a single number/letter, y is a
 *number/letter/./_ and z is a number/letter/.
 *Parameters:A string which is the candidate username
 *return: true if valid false otherwise
 */
bool User::checkUsernameFormat(std::string username){
   	const std::regex pattern("(\\w+)(\\.|_)?(\\w*)@(\\w+)(\\.(\\w+))+");
	return std::regex_match(username, pattern);
}


/*
 *Function Name:checkPasswordFormat
 *Description:checks that a valid password has been provided. A valid password
 *is made of numbers and letters and is 6-12 characters long
 *Parameters:string for candidate password
 *return: true if valid format, false otherwise
 */
bool User::checkPasswordFormat(std::string password){
	const std::regex pattern("(\\w+)");
	if((password.length() >= 6) && (password.length() <=	12)){
		return std::regex_match(password, pattern);
	}
	return false;
}


/*
 *Function Name:checkNameFormat
 *Description:Checks to make sure a name is of proper format. A name can be 12
 *characters long and must start with a space. Only letters and spaces are valid
 *Parameters:a string for the candidate name
 *return: true if valid, false otherwise
 */	
bool User::checkNameFormat(std::string name){
	const std::regex pattern("[a-zA-Z][a-zA-Z\\s]+");
	if(name.length() <= 12){
		return regex_match(name, pattern);
	}
	else return false;
}

/*
 *Function Name:empty
 *Description: checks if the user object exists
 *Parameters:N/A
 *return: true if empty, false otherwise
 */	
bool User::empty(){
	return (email.size() == 0);
}
