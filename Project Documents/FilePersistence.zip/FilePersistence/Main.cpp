#include <Wt/WApplication>

#include "App.h"

#include "User.h"
#include "FileController.h"
#include <iostream>

using namespace Wt;

WApplication *createApplication(const WEnvironment& env) {

	return new App(env);
}

int main(int argc, char **argv) {

	return WRun(argc, argv, &createApplication);
}
