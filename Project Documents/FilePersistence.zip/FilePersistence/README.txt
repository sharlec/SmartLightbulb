FilePersistence was made by Jacob (please contact me if you have any questions
about how to use this). File manipulation algorithms can be found in
FileController.h and FileController.cpp.

To compile, enter the following command:
    make

To run, enter the following command:
    make run

To remove compiled files, enter the following command:
    make clean

If your terminal does not recognize make, enter the following command:
    sudo apt-get install make

Usage instructions:
    In App.cpp, you'll find this program's test harness functions. To use them,
    change the value of the copy variable (on line 15) to one of the following:
        1 - run the copy function to copy the string from sampleJson.txt to
            data.txt (the data file) (note: this function can somtimes cause
            problems with the other test harnesses. If you face any issues,
            manually copy-paste the contents of sampleJson.txt to data.txt
            before running the test harness functions)
        0 - don't run the copy function
    and change the test variable (on line 16) to one of the following:
        0 - don't run any test functions
        1 - run the function to test deleteUser() in FileController.cpp
        2 - run the function to test createUser() in FileController.cpp
        3 - run the function to test saveUser() in FileController.cpp
        4 - run the function to test getUser() in FileController.cpp
    
    These tests will be executed when you navigate to localhost:8080 in your
    web browser.
    
    Where to find test harness function outputs:
        delete/create/saveUser functions: in the data.txt file
        getUser function: printed to the terminal (will be prefaced by
            "**********GET_USER TESTING OUTPUT**********")
