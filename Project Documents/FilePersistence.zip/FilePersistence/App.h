#ifndef APP_H
#define APP_H

#include <Wt/WApplication>

class App : public Wt::WApplication {

	public:
		App(const Wt::WEnvironment& env);

		void copyFile();

		void testDeleteUser();
		void testCreateUser();
		void testSaveUser();
		void testGetUser();

	private:

};

#endif
