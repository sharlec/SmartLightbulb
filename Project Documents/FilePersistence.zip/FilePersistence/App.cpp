#include <string>
#include <iostream>

#include <Wt/WApplication>
#include <Wt/WContainerWidget>
#include <Wt/WText>

#include "App.h"
#include "FileController.h"

using namespace Wt;

App::App(const WEnvironment& env) : WApplication(env) {

	int copy = 0;
	int test = 1;

	setTitle("JSON Test");

	root()->addWidget(new WText("Application running."));

	if (copy == 1)
		copyFile();
	
	if (test == 1)
		testDeleteUser();
	else if (test == 2)
		testCreateUser();
	else if (test == 3)
		testSaveUser();
	else if (test == 4)
		testGetUser();
}

void App::copyFile() {
	
	std::ifstream  src("sampleJson.txt", std::ios::binary);
    std::ofstream  dst("data.txt", std::ios::binary);

    dst << src.rdbuf();
}

void App::testDeleteUser() {
	
	FileController fileController;

	fileController.deleteUser("dave@gmail.com");
	fileController.deleteUser("jane@gmail.com");

	fileController.deleteUser("asdf@gmail.com");
}

void App::testCreateUser() {
	
	User user;

	user.setEmail("william@gmail.com");
	user.setFirstName("William");
	user.setLastName("Bishop");
	user.setHashedPassword("pass4");
	user.setPhoneNumber("519-3465-3411");

	User user2;
	
	user2.setEmail("jennifer@gmail.com");
	user2.setFirstName("Jennifer");
	user2.setLastName("Page");
	user2.setHashedPassword("pass5");
	user2.setPhoneNumber("519-236-5871");
	
	User user3;

	FileController fileController;

	fileController.createUser(user);
	fileController.createUser(user2);
	fileController.createUser(user3);
}

void App::testSaveUser() {
	
	User user;

	user.setEmail("dave@gmail.com");
	user.setFirstName("Dave");
	user.setLastName("Mason");
	user.setHashedPassword("newPass2");
	user.setPhoneNumber("519-239-1292");

	User user2;

	FileController fileController;

	fileController.saveUser(user);
	fileController.saveUser(user2);
}

void App::testGetUser() {
	
	User user;
	
	FileController fileController;
	
	int test1 = fileController.getUser(user, "john@gmail.com", "pass1");
	
	User user2;
	
	int test2 = fileController.getUser(user2, "jack@gmail.com", "somePass");
	
	User user3;
	
	int test3 = fileController.getUser(user3, "dave@gmail.com", "wrongPass");
	
	std::cerr << "**********GET_USER TESTING OUTPUT**********" << std::endl;
	
	std::cerr << "Test1 result: ";
	std::cerr << test1 << std::endl << std::endl;
	
	std::cerr << "Test2 result: ";
	std::cerr << test2 << std::endl << std::endl;
	
	std::cerr << "Test3 result: ";
	std::cerr << test3 << std::endl << std::endl;
	
	std::cerr << "user's attributes:" << std::endl;
	std::cerr << "email : " + user.getEmail() << std::endl;
	std::cerr << "firstName : " + user.getFirstName() << std::endl;
	std::cerr << "lastName : " + user.getLastName() << std::endl;
	std::cerr << "hashedPassword : " + user.getHashedPassword() << std::endl;
	std::cerr << "phoneNumber : " + user.getPhoneNumber() << std::endl;
	
	std::cerr << "**********END OF GET_USER TESTING OUTPUT**********" << std::endl;
}
