#ifndef USER_H
#define USER_H

#include <string>

class User {

	public:
		User();
        ~User();

        std::string getEmail();
        std::string getFirstName();
        std::string getLastName();
		std::string getHashedPassword();
        std::string getPhoneNumber();

        void setEmail(std::string email);
        void setFirstName(std::string firstName);
        void setLastName(std::string lastName);
		void setHashedPassword(std::string hashedPassword);
        void setPhoneNumber(std::string phoneNumber);

		bool empty();

	private:
        std::string email;
        std::string firstName;
        std::string lastName;
		std::string hashedPassword;
        std::string phoneNumber;
};

#endif
