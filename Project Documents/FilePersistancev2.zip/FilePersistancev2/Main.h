#ifndef APP_H
#define APP_H

void copyFile();

void testDeleteUser();
void testCreateUser();
void testSaveUser();
void testGetUser();

#endif
