#include <string>

#include "User.h"

using namespace std;

User::User() { }

User::~User() { }

string User::getEmail() { return email; }

string User::getFirstName() { return firstName; }

string User::getLastName() { return lastName; }

string User::getHashedPassword() { return hashedPassword; }

string User::getPhoneNumber() { return phoneNumber; }

void User::setEmail(string email) { this->email = email; }

void User::setFirstName(string firstName) { this->firstName = firstName; }

void User::setLastName(string lastName) { this->lastName = lastName; }

void User::setHashedPassword(string hashedPassword) {
    this->hashedPassword = hashedPassword; }

void User::setPhoneNumber(string phoneNumber) {
    this->phoneNumber = phoneNumber; }

bool User::empty() {
    if (email == "" &&
        firstName == "" &&
        lastName == "" &&
        phoneNumber == "") {

        return true;
    }

    return false;
}
