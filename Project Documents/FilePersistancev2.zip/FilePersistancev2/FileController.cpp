#include <string>
#include <fstream>
#include <iostream>
#include <cstdio>
#include <stack>

#include <Wt/Json/Object>
#include <Wt/Json/Value>
#include <Wt/Json/Parser>

#include "FileController.h"
#include "User.h"

using namespace std;

FileController::FileController() { }

FileController::~FileController() { }

bool FileController::userExists(string email) {
	
	string dataStr = readFromFile();
	
	if (emailLocation(email, dataStr) != string::npos)
		return true;
	else
		return false;
}

int FileController::getUser(User &user, string email,
	string hashedPassword) {

	string dataStr = readFromFile();

	Wt::Json::Object jsonObj;

	Wt::Json::parse(dataStr, jsonObj);

	if (jsonObj.get(email).type() == Wt::Json::NullType)
		return 1;
	
	const Wt::Json::Object& userObj = jsonObj.get(email);

	string jsonHashedPassword = userObj.get("hashedPassword");

	if (jsonHashedPassword != hashedPassword)
			return 2;
	
	string jsonFirstName = userObj.get("firstName");
	string jsonLastName = userObj.get("lastName");
	string jsonPhoneNumber = userObj.get("phoneNumber");
	
	user.setEmail(email);
	user.setFirstName(jsonFirstName);
	user.setLastName(jsonLastName);
	user.setHashedPassword(jsonHashedPassword);
	user.setPhoneNumber(jsonPhoneNumber);
	
	return 0;
}

void FileController::saveUser(User &user) {

	if (user.empty())
	 	return;

	string dataStr = readFromFile();

	if (!userExists(user.getEmail()))
		return;

	deleteUser(user.getEmail());

	createUser(user);
}

void FileController::createUser(User &user) {

	if (user.empty())
		return;

	string dataStr = readFromFile();

	if (userExists(user.getEmail()))
		return;

	string userStr = "";

	userStr.append(
		"\"" + user.getEmail() + "\":{"
			"\"firstName\":\"" + user.getFirstName() + "\","
			"\"lastName\":\"" + user.getLastName() + "\","
			"\"hashedPassword\":\"" + user.getHashedPassword() + "\","
			"\"phoneNumber\":\"" + user.getPhoneNumber() + "\""
		"}"
	);

	string::iterator currentChar;
	currentChar = dataStr.end();

	while ((currentChar - dataStr.begin()) != 0) {
		if (*currentChar == '}') {
			size_t currentPos = currentChar - dataStr.begin();
			
			dataStr.insert(currentPos, userStr);
			
			if (dataStr.at(currentPos - 1) != '{')
				dataStr.insert(currentPos, ",");
			
			break;
		}
		currentChar--;
	}

	writeToFile(dataStr);
}

void FileController::deleteUser(string email) {

	string dataStr = readFromFile();

	size_t emailLoc = emailLocation(email, dataStr);

	if (!userExists(email))
		return;

	emailLoc--;

	int currentPos = emailLoc;

	char currentChar = dataStr.at(currentPos);

	while(currentChar != '\0') {
		if (currentChar == '{') {
			stack<int> testStack;
			testStack.push(1);

			while(currentChar != '\0') {
				currentPos++;
				currentChar = dataStr.at(currentPos);

				if (currentChar == '{') {
					testStack.push(1);
				} else if (currentChar == '}') {
					testStack.pop();
				}

				if (testStack.empty() == true)
					break;
			}
			break;
		}

		currentPos++;
		currentChar = dataStr.at(currentPos);
	}

	if (currentChar == '\0')
		currentPos--;

	int eraseLength = (currentPos - emailLoc) + 1;

	if (dataStr.at(currentPos + 1) == ',')
		eraseLength++;

	dataStr.erase(emailLoc, eraseLength);

	if (dataStr.at(emailLoc) == '}') {
		emailLoc -= 1;
		dataStr.erase(emailLoc, 1);
	}

	writeToFile(dataStr);
}

size_t FileController::emailLocation(string email, string dataStr) {
	
	return dataStr.find(getEmailStr(email));
}

string FileController::getEmailStr(string emailStr) {
	
	string modifiedEmailStr = "";
	
	modifiedEmailStr.append(emailStr + "\":{");
	
	return modifiedEmailStr;
}

string FileController::fileToString() {

	string dataStr = "";

	string line = "";

	fstream file;
	file.open("data.txt");

	while(getline(file, line))
		dataStr.append(line);

	file.close();

	return dataStr;
}

void FileController::stringToFile(string dataStr) {

	remove("data.txt");

	ofstream file("data.txt");
    
	file << dataStr;
    
	file.close();
}

void FileController::markFileAccessable(bool accessable) {

	string dataStr = fileToString();

	if(accessable)
		dataStr = removeSemaphore(dataStr);
	else
		dataStr.insert(0, "0");

	stringToFile(dataStr);
}

bool FileController::isFileAccessable() {

	string dataStr = fileToString();

	if (dataStr == "")
		return false;

	string semaphore;

	semaphore = dataStr.substr(0, 1);

	if(semaphore.compare("0") == 0)
		return false;

	return true;
}

string FileController::removeSemaphore(string dataStr) {

	string checkCharacter;

	while(dataStr.length() != 0) {
		checkCharacter = dataStr.substr(0, 1);

		if(checkCharacter.compare("{") != 0)
			dataStr.erase(0, 1);
		else
			break;
	}

	return dataStr;
}

string FileController::readFromFile() {
	while(!isFileAccessable());
	markFileAccessable(false);
	string dataStr = fileToString();
	markFileAccessable(true);

	dataStr = removeSemaphore(dataStr);

	return dataStr;
}

void FileController::writeToFile(string dataStr) {
	while(!isFileAccessable());
	markFileAccessable(false);
	stringToFile(dataStr);
	markFileAccessable(true);
}
