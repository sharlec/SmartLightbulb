#include <string>
#include <iostream>

#include "Main.h"
#include "FileController.h"
#include "User.h"

using namespace std;

int main() {

	int copy = 0;
	int test = 1;
    
	if (copy == 1)
		copyFile();
    
	if (test == 1)
		testDeleteUser();
	else if (test == 2)
		testCreateUser();
	else if (test == 3)
		testSaveUser();
	else if (test == 4)
		testGetUser();
		
	return 0;
}

void copyFile() {
	
	ifstream  src("sampleJson.txt", ios::binary);
    ofstream  dst("data.txt", ios::binary);

    dst << src.rdbuf();
}

void testDeleteUser() {
	
	FileController fileController;

	fileController.deleteUser("dave@gmail.com");
	fileController.deleteUser("jane@gmail.com");

	fileController.deleteUser("asdf@gmail.com");
}

void testCreateUser() {
	
	User user;

	user.setEmail("william@gmail.com");
	user.setFirstName("William");
	user.setLastName("Bishop");
	user.setHashedPassword("pass4");
	user.setPhoneNumber("519-3465-3411");

	User user2;
	
	user2.setEmail("jennifer@gmail.com");
	user2.setFirstName("Jennifer");
	user2.setLastName("Page");
	user2.setHashedPassword("pass5");
	user2.setPhoneNumber("519-236-5871");
	
	User user3;

	FileController fileController;

	fileController.createUser(user);
	fileController.createUser(user2);
	fileController.createUser(user3);
}

void testSaveUser() {
	
	User user;

	user.setEmail("dave@gmail.com");
	user.setFirstName("Dave");
	user.setLastName("Mason");
	user.setHashedPassword("newPass2");
	user.setPhoneNumber("519-239-1292");

	User user2;

	FileController fileController;

	fileController.saveUser(user);
	fileController.saveUser(user2);
}

void testGetUser() {
	
	User user;
	
	FileController fileController;
	
	int test1 = fileController.getUser(user, "john@gmail.com", "pass1");
	
	User user2;
	
	int test2 = fileController.getUser(user2, "jack@gmail.com", "somePass");
	
	User user3;
	
	int test3 = fileController.getUser(user3, "dave@gmail.com", "wrongPass");
	
	cerr << "**********GET_USER TESTING OUTPUT**********" << endl;
	
	cerr << "Test1 result: ";
	cerr << test1 << endl << endl;
	
	cerr << "Test2 result: ";
	cerr << test2 << endl << endl;
	
	cerr << "Test3 result: ";
	cerr << test3 << endl << endl;
	
	cerr << "user's attributes:" << endl;
	cerr << "email : " + user.getEmail() << endl;
	cerr << "firstName : " + user.getFirstName() << endl;
	cerr << "lastName : " + user.getLastName() << endl;
	cerr << "hashedPassword : " + user.getHashedPassword() << endl;
	cerr << "phoneNumber : " + user.getPhoneNumber() << endl;
	
	cerr << "**********END OF GET_USER TESTING OUTPUT**********" << endl;
}

